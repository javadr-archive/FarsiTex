========================================================================
readme.txt (FarsiTeX Distribution)
========================================================================

                     FarsiTeX Distribution Guide

Welcome to FarsiTeX!

FarsiTeX is a typesetting system based on Donald Knuth's TeX. It accepts
almost all commands of TeX and LaTeX 2.09 in multi-lingual Persian/Latin
modes and produces DVI and PDF output, which can be processed by many
available device drivers.


Current Version
===============
This is FarsiTeX Distribution Version 1.0.  For version number of
individual components, please see their respective file headers.

Please read "changes.txt" for the new features of this release.

This is an stable version of FarsiTeX. Although it has been extensively
used for many years prior to this release, we don't claim or guarantee
that it is free of any bug.  After receiving bug reports, we will try
to fix them in the next release.


Manual
======
The FarsiTeX system is described in:

  A Guide to FarsiTeX, by Mohammad Ghodsi, Roozbeh Pournader, and
  Behdad Esfahbod, 2004 (in Persian).

Computer-readable versions of this manual is included with this release.

However, the LaTeX 2.09 book should be considered as the main reference
manual for FarsiTeX (Leslie Lamport, LaTeX: A document Preparation
System, first edition, Addison-Weseley, 1985.) So, if you are already
familiar with LaTeX, you can easily start using FarsiTeX.


FarsiTeX on the Web
===================
The latest version of FarsiTeX is always available on the internet
through FarsiTeX's official homepage at

  http://farsitex.org/

FarsiTeX users should regularly check this homepage and update their
installations.


Copyright
=========
FarsiTeX is Copyright (C) 1996--2004 The FarsiTeX Project Team.
All rights are reserved.

FarsiTeX is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

Every piece of software accompanying FarsiTeX is copyrighted by its
respective author(s). See the file "legal.txt" for more details.


FarsiTeX Mailing Lists
======================

There are three mailing lists for FarsiTeX:

  - farsitex-announce:
       For FarsiTeX-related announcements, including new releases. This
       is the place to watch if you want to be up to date.  Every user
       is recommended to be a subscriber.

  - farsitex-user:
       For users.  This is the place to ask your questions.

  - farsitex-disc:
       For discussion.  This is the place for requesting new features,
       or suggesting ideas to make FarsiTeX better.

To subscribe, or to look at the archives, please visit:

	http://farsitex.org/lists.php

--- Mohammad Ghodsi (ghodsi@farsitex.org) ------------------------------
--- Roozbeh Pournader (roozbeh@farsitex.org) ---------------------------
--- Behdad Esfahbod (behdad@farsitex.org) ------------------------------
--- Copyright 1996--2004, FarsiTeX Project Team. All rights reserved ---
--- Last modified $Date: 2001/03/06 20:43:01 $ -------------------------
