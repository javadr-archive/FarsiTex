output_format 1
compress_level 0
decimal_digits 2
page_width 210mm
page_height 297mm
% old version of pdfTeX:
%hoffset 1in
%voffset 1in
% new version of pdfTeX:
horigin 1in
vorigin 1in
% map standard.map
% map +psfonts.map
map basefnts.map
map +rawfnts.map
map +cm.map
map +logo.map
% map +lucida.map
% map +misc.map
map +csfont-e.map
% map +cmttf.map
% map +test.map
% map +ttftest.map
% map +mono.map
