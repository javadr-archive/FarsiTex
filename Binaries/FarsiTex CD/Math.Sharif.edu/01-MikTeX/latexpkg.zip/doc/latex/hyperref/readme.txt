This package is used to emend cross-referencing commands in LaTeX to
produce some sort of \special commands; there are backends for the
\special set defined for HyperTeX dvi processors, for embedded pdfmark
commands for processing by Acrobat Distiller (dvips and dvipsone), for
dviwindo, for pdfTeX, for TeX4ht, and for VTEX's pdf and HTML
backends.

Included are:

  a) `backref' a package by David Carlisle to provide links back from 
     bibliography to the main text; these are hypertext links after using
     hyperref.
  b)  `nameref' a package to allow reference to the *names* of sections rather
     than their numbers.

Sebastian Rahtz <sebastian.rahtz@oucs.ox.ac.uk>
Heiko Oberdiek <oberdiek@ruf.uni-freiburg.de> 

December 1994-October 1999

Additional Packages
===================
Depending on the driver, hyperref loads other packages:
* url.sty
    CTAN:macros/latex/contrib/other/misc/url.sty
* keyval.sty, color.sty:
    CTAN:macros/latex/required/graphics/
  An uptodate pdftex.def is available at
    http://www.tug.org/applications/pdftex/pdftex.def
    CTAN:macros/pdftex/graphics/pdftex.def

BUGS
----
 - (half-done) hyper images (link from thumbnail in text)

TODO
----

FEATURES
- PDF threads
- more for PDF forms
- per object setting
- vary gap between text and box
