------------------------------------------------------------
            PSNFSS -- installation instructions
------------------------------------------------------------
                                      PSNFSS v8.1 2000-01-12
                                              Walter Schmidt
                                 walter.schmidt@arcormail.de
                               

Contents
--------

- Overview
- Removing obsolete files
- Installing the virtual fonts, metrics and fd files
- Installing the PSNFSS macro packages
- Fonts required for PSNFSS
- Configuring dvips, pdfTeX etc.
- Extra packages required for PSNFSS
- Making sure that everything works
- Files from PSNFSS v7.x, which are no longer part of the
  distribution.


Overview
--------

PSNFSS, developed by Sebastian Rahtz, is a set of LaTeX2e
package files to load common PostScript text and symbol
fonts, together with packages for typesetting math using
virtual math fonts for Times and Palatino.

The collection is useless without the font description (fd)
files, virtual fonts (vf) and font metric (tfm) files for
the font families used by the packages.  On CTAN, those for
the Base 35 fonts are collected in the file lw35nfss.zip.
This archive also contains a font map file for dvips, and a
file named 8r.enc to reencode the Type1 fonts in a way that
is suitable for use with TeX.  Additionally, metrics, fd's
and font map files for the free typefaces Adobe Utopia and
Bitstream Charter are provided in the file freenfss.zip.

This document describes how to install PSBFSS 8.1.  The
details should be applicable to any TeX system with a
TDS-compliant directory layout.

*  Important changes and additions have been introduced with
*  this version; see the file changes.txt.
*
*  Notice that you _must_ install the new .tfm, .vf and .fd
*  files from the archive lw35nfss.zip in order to make 
*  PSNFSS version 8.1 work properly!

A detailed description of how to _use_ PSNFSS with LaTeX,
can be found in the PDF document psnfss2e.pdf.


Removing obsolete files
-----------------------

The directory layout of your existent TeX system may differ
from PSNFSS 8.1, so you may have to delete certain files and
directories before installing this version; otherwise
obsolete files may not be overwritten in the next step.

* The font definition (.fd) files are kept in the directory
texmf/tex/latex/psnfss, as opposed to any sudirectories of
this).  Remove the following directories, if they exist on
your TeX system:

texmf/tex/latex/psnfss/bch
texmf/tex/latex/psnfss/pag
texmf/tex/latex/psnfss/pbk
texmf/tex/latex/psnfss/pcr
texmf/tex/latex/psnfss/phv
texmf/tex/latex/psnfss/pnc
texmf/tex/latex/psnfss/ppl
texmf/tex/latex/psnfss/psy
texmf/tex/latex/psnfss/ptm
texmf/tex/latex/psnfss/put
texmf/tex/latex/psnfss/pzc
texmf/tex/latex/psnfss/pzd
texmf/tex/latex/psnfss/pzc
texmf/tex/latex/psnfss/pzd

* There are no separate subdirectories for the "mathptm" and
"mathptmx" virtual math fonts; instead, these fonts are kept
together with the "Times" text fonts.  In case the following
directories exist on your TeX system, they are to be
removed:

texmf/fonts/tfm/adobe/mathptm
texmf/fonts/tfm/adobe/mathptmx
texmf/fonts/vf/adobe/mathptm
texmf/fonts/vf/adobe/mathptmx
texmf/tex/latex/mathptm
texmf/tex/latex/mathptmx

* The "mathpple" bundle was distributed and installed
separately so far; it is now part of PSNFSS.  In case it was
installed, the following directories must be removed now:

texmf/fonts/tfm/public/mathpple
texmf/fonts/vf/public/mathpple
texmf/tex/latex/mathpple
texmf/doc/latex/mathpple

* Make sure that there is only one instance of the file 
psyr.tfm (metrics for Adobe Symbol) in your TeX system; it 
must reside in the directory texmf/fonts/tfm/adobe/symbol.

* The file psyro.tfm resides in the directory
texmf/fonts/tfm/adobe/times now, since it is used in
conjunction with the virtual Times math fonts only.  Be sure
to delete any other instance of this file, which may reside,
e.g., in the directory texmf/fonts/tfm/adobe/symbol.


Installing the virtual fonts, metrics and fd files
--------------------------------------------------

Unzip lw35nfss.zip and freenfss.zip in the texmf root
directory (usually named texmf) of your TeX system; thus all
files will be unpacked into the right directories.

Notice, that the archives lw35nfss.zip and freenfss.zip do
_not_ comprise the metrics of the "raw" (= not re-encoded)
PostScript text fonts.  Whether or not these metrics are
actually required, is system-dependent; besides, they are
not special for PSNFSS.


Installing the PSNFSS macro packages
------------------------------------

Put all the files from the CTAN directory
macros/latex/required/psnfss (except for the .zip archives)
into a directory where you keep documented LaTeX sources.
In a TDS compliant system this should be the directory

  texmf/source/latex/psnfss.

Run LaTeX on the installation script psfonts.ins; this will
create the packages.  

Move all the .sty files, which have been created, to a
directory where LaTeX will find them.  In a TDS compliant
system this should be the directory 

  texmf/tex/latex/psnfss.

The latter step is executed automagically by the
installation script, provided that your DocStrip program has
been configured appropriately and the target directory
exists already.

Move the documentation file psnfss2e.pdf to a suitable
directory; in a TDS compliant system this should be

  texmf/doc/latex/psnfss.

You may want to typeset the documentation of the package
code, too:  Run the file psfonts.dtx through LaTeX.


Fonts required for PSNFSS
-------------------------

The "Base 35" fonts
  Whether or not these fonts must be available to the dvi
  driver as "real" Type1 fonts, depends on the particular
  program (dvips, pdfTeX, VTeX) and whether the fonts are to
  be embedded in the final PostScript or PDF documents.
  
Adobe Utopia
Bitstream Charter
  These Type1 fonts can be obtained for free from various
  sources.  Be sure to install the files with the names
  according to the KB scheme:
  
  Utopia-Regular        putr8a.pfb
  Utopia-Italic         putri8a.pfb
  Utopia-Bold           putb8a.pfb
  Utopia-BoldItalic     putbi8a.pfb
  CharterBT-Roman       bchr8a.pfb
  CharterBT-Italic      bchri8a.pfb
  CharterBT-Bold        bchb8a.pfb
  CharterBT-BoldItalic  bchbi8a.pfb
  
Computer Modern
RSFS (Ralph Smith's Formal Script)
Euler Math
  These font families are required when typesetting math
  using the packages mathptm, mathptmx, or mathpple.
  
  They are available in Type1 as well as METAFONT format; it
  is recommended to provide the Type1 variants, if you want
  to create PostScript or PDF documents.  The particular
  fonts eurm10 (Euler Roman 10pt) and eurb10 (Euler Roman
  Bold 10pt) are special:  They _must_ be provided in Type1
  format so that obliqued versions, named eurmo10 and
  eurbo10, can be generated from them.


Configuring dvips, pdfTeX etc.
------------------------------

The file dvips/psnfss/psnfss.map is a font map file for use
with dvips , whose entries cover the Base 35 fonts plus
eurmo10 and eurbo10 -- see above!  You may rename the file
to psfonts.map and use it as a minimal font map for use with
the dvips program.  

This sample psnfss.map does not yet contain any entries for
the above-mentioned extra fonts.  Suitable entries for these
fonts should be added, in case they are actually available
as Type1 with your TeX system.  Particularly, charter.map
and utopia.map should be appended to the map file, if these
typefaces are actually installed.

Notice, that there are no entries for the "raw" (= not
re-encoded) PostScript text fonts in the map files, because
these are usually not required for use with dvips.

The PSNFSS distribution does _not_ include any font map
files for use with other applications, e.g., pdfTeX or VTeX.
They can be modeled on psnfss.map, charter.map and
utopia.map; it may be necessary to add entries for the raw
PostScript text fonts here.


Extra packages required for PSNFSS
----------------------------------

The "Graphics" bundle must be installed, since PSNFSS will
require the package keyval.sty.


Making sure that everything works
---------------------------------

Run the test files test0.tex, test1.tex, mathtest.tex and
pitest.tex through LaTeX.


Files from PSNFSS v7.x, which are no longer part of the
distribution.
-------------------------------------------------------

The metrics, virtual fonts, fd's and map files for the
commercially available font families Monotype Times,
Monotype Baskerville, Adobe Garamond, Adobe Bembo and Adobe
Lucida can be found in the CTAN directory fonts/psfonts.

The files for the Lucida Bright and Math-Times fonts are
distributed from the CTAN directory <??> now.

Particular metrics and style files for URW Nimbus Roman and
URW Nimbus Sans are not needed:  These are nothing but free
"clones" of the font families Adobe Times and Adobe
Helvetica, and your TeX system will use the URW fonts in
place of Times and Helvetica anyway, unless you have
actually installed the Adobe fonts.

-- finis
