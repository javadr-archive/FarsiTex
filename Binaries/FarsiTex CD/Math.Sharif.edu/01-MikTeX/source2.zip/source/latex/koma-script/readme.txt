Sie finden eine deutsche Version dieses Textes in liesmich.txt!

KOMA-Script bundle
==================

Redistribution of this bundle is allowed provided that all files that
make up the KOMA-Script bundle are contained.  The list of all files
making up this bundle is given below.

This bundle has been created for the use with LaTeX2e. Although a
great effort has been made to eliminate all bugs, this bundle is
provided `as is' without warranty of any kind, either expressed or
implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose.  The entire risk
as to the quality and performance of the program is with you.


The files:
----------

All files marked with an exclamation mark (!) are REQUIRED as a part
of the distribution. You are NOT ALLOWED to distribute them
separately, any distribution MUST contain ALL of the required
files. All unmarked files are OPTIONAL parts of the distribution. You
may leave them out but you MUST NOT redistribute them without
including the REQUIRED files.

   knownbug.txt  - List of bug reports since November 25th,1996.
 ! komabug.tex   - LaTeX-file for creating a bug report.
		   USE THIS FILE FOR REPORTING BUGS!
 ! komascr.ins   - Install file for the KOMA-Script bundle. Calls
                   (and requires!) scrclass.ins, scrtime.ins and 
		   scrpage.ins.
 ! scrclass.ins  - Install file for scrclass.dtx, scrlettr.dtx and
                   script20.dtx. Required by komascr.ins.
 ! scrclass.dtx  - contains:
    scrartcl.cls  - KOMA-Script class as a replacement for article.cls,
    scrreprt.cls  - KOMA-Script class as a replacement for report.cls,
    scrbook.cls   - KOMA-Script class as a replacement for book.cls,
    typearea.sty  - KOMA-Script style for the calculation of the type
                    area. 
 ! scrlettr.dtx  - contains:
    scrlettr.cls  - KOMA-Script class as a replacement for letter.cls,
    phone.tex     - Interactive file to generate a phone list from
                    adr-files.
    dir.tex       - Interactive file to generate lists from adr-files.
    addrconv.bst  - BibTeX style to convert BibTeX address databases 
                    into adr-files.
    addrconv.tex  - Interactive file to generate the aux-files needed
                    by addrconv.bst.
    birthday.bst  - BibTeX style to generate birthday lists in
                    adr-file format from BibTeX address databases.
    birthday.tex  - Interactive file to generate the aux-files needed
                    by birthday.bst.
    email.bst     - BibTeX style to generate email lists in adr-file
                    format from BibTeX address databases.
    email.tex     - Interactive file to generate the aux-files needed
                    by email.bst.
    example.bib   - An example for a BibTeX address database.
   adrguide.tex  - original manual for addrconv.*
 ! script20.dtx  - contains:
    script.sty    - style provided for compatibility,
    script_s.sty  - style provided for compatibility,
    script_l.sty  - style provided for compatibility.
 ! scrtime.ins   - Install file for scrtime.dtx.
                   Required by komascr.ins.
 ! scrtime.dtx   - contains:
    scrtime.sty   - style for formatting a time,
    scrdate.sty   - style for formatting the day of the week.
 ! scrpage.ins   - Install file for scrpage.dtx.
                   Required by komascr.ins.
 ! scrpage.dtx   - contains:
    scrpage.sty   - design your own page headers and footers.
 ! scrguide.tex  - the documentation (in German). Requires several
                   parts of the KOMA-Script bundle.
 ! scrguide.dvi  - a ready-to-use version of scrguide.tex (DVI).
   scrguide.ps   - a ready-to-use version of scrguide.tex (PostScript).
   scrguide.pdf  - a ready-to-use version of scrguide.tex (Adobe's PDF).
   scrguide.ind  - index file for scrguide.tex.
   screnggu.tex  - English version of scrguide.tex, somewhat
                   shortened. If in doubt, use scrguide.tex.
		   Requires several parts of the KOMA-Script bundle. 
   screnggu.dvi  - a ready-to-use version of screnggu.tex (DVI)
   screnggu.ind  - index file for screnggu.tex.
 ! scrguide.ist  - MakeIndex style for scrguide and screnggu.
 ! scr_new1.tex  - information concerning the first version of
                   KOMA-Script (German).
 ! scr_new2.tex  - additional information (German).
 ! scr_new3.tex  - additional information (German).
 ! scr_new4.tex  - additional information (German).
 ! scr_new5.tex  - additional information (German).
 ! scr_new6.tex  - additional information (German).
 ! scr_new7.tex  - additional information (German).
 ! scr_new8.tex  - additional information (German).
 ! scr_new9.tex  - additional information (German).
 ! scrnew10.tex  - additional information (German).
 ! scrnew11.tex  - additional information (German).
 ! scrnew12.tex  - additional information (German).
 ! scrnew13.tex  - additional information (German).
 ! scrnew14.tex  - additional information (German).
 ! scrnew15.tex  - additional information (German).
 ! scrnew16.tex  - additional information (German).
 ! scrnew17.tex  - additional information (German).
 ! scrnew18.tex  - most recent information (German).
   scr_new1.dvi \
   ...           > ready-to-use versions of the above.
   scrnew18.dvi /  
 ! liesmich.txt  - read this, if you prefer German.
 ! readme.txt    - you are just reading it.
 ! INSTALL.TXT	 - the installation manual (English)
 ! INSTALLD.TXT	 - the installation manual (German).
 ! LEGAL.TXT	 - the dry part: legal stuff, warranty, license (English)
 ! LEGALDE.TXT	 - the dry part: legal stuff, warranty, license (German)

 If one or more of the above files marked with an exclamation mark (!)
 is missing, please inform the author about the missing files and
 where you have gotten the bundle from.

          MausNet:   Markus Kohm @ HD   (please read 'ATTENTION' below!)
	  InterNet:  Markus.Kohm@gmx.de
          Post:      Markus Kohm
                     Fichtenstrasse 63
                     68535 Edingen-Neckarhausen 

* ATTENTION: Don't send more than 48kbyte to a MausNet-user at one 
*            day!

  If you cannot reach me at one of the addresses above, ask at one of 
  the following groups:
    MausNet, Fido, Usenet: de.comp.text.tex


Installation:
-------------

The following describes the general procedure for installing this
bundle. If you have a TeX system compatible to TDS (most of the newer
TeX systems are), please read INSTALL.TXT.

* ATTENTION: You need a complete LaTeX2e!

  Copy all files to a directory, where TeX/LaTeX can find them.
  Run komascr.ins through LaTeX, e.g. at UNIX type:
    tex "&latex" komascr.ins
  or
    latex komascr.ins
  You'll get a couple of new cls-, sty- and tex-files. Copy them to
  the corresponding LaTeX-directory. See INSTALL.TXT for further
  information.
  Do not forget to run the initialization procedures specific to your
  TeX distribution, e.g. if you use teTeX, run 'texhash'

* ATTENTION: To create the complete documentation (it's in German!) you
*            need german.sty! You don't need to generate the
*            documentation, because there are ready-to-use dvi files
*            available. However, as the manual serves as an example of
*            how to use KOMA-Script, it might be a good idea to have
*            at least a look.

  To create the manual run scrguide.tex through LaTeX, e.g. at UNIX
  type:
    tex "&latex" scrguide.tex
  or:
    latex scrguide.tex
  You need to run latex three times (to get the table of contents and
  the references right) before the manual is completed. If you want
  an index, you have to use precompiled scrguide.ind or you have to
  create a new index running scrguide.idx through makeindex
  (makeindx) before the last (third) LaTeX run.  If you are using a
  UNIX system, type:
    makeindex -g -r -s scrguide.ist scrguide.idx
  resp.
    makeindx -g -r -s scrguide.ist scrguide.idx

  If you want the documentation specific to the implementation, you
  have to run the dtx-files through LaTeX. Again, using a UNIX system
  type: 
    tex "&latex" scrclass.dtx
  or
    latex scrclass.dtx

  Most likely you won't need those as, the user manual should be
  sufficient. 

+ IMPORTANT: Do not forget to run scrguide.tex and each dtx-file
+            through LaTeX three times, if you like to have correct
+            references and table of contents.

  Last but not least, you should run all scr_news-files through LaTeX
  and read all the documentation.


Bug-reports:
------------
  To report a bug, run 'komabug.tex' through LaTeX and fill in the
  fields as concise as possible and send the form upon completion to
  the author at one of the addresses above.

* ATTENTION: IT IS HIGHLY RECOMMENDED TO USE KOMABUG.TEX FOR BUG
*            REPORTS. IF YOU SEND YOUR REPORT TO THE MAUSNET ADDRESS,
*            BE REMINDED OF THE DAILY MAIL-LIMIT!

Changes since first Version at 1994/07/07:
------------------------------------------
  You'll find all changes at the dtx-files and the glossaries.


Date of file:
---------
  2000/06/11


