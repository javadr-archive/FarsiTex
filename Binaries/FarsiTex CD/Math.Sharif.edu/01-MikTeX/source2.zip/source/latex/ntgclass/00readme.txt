                       NTG document classes distribution

                                   3 March 1999

This file contains the distribution guide for the new  version
of the NTG document classes and the A4 package. 
The classes are maintained by NTG Working Group 13

This distribution is described in the files ending with .txt.

 * 00readme.txt is this file.

 * manifest.txt lists all the files in the distribution.

For more information about the document classes see the file
ntgclass.tex. 

These files can be redistributed and/or modified under the terms
of the LaTeX Project Public License Distributed from CTAN
archives in directory macros/latex/base/lppl.txt; either
version 1 of the License, or any later version.

Please do not request updates from us.  Distribution is done only
through mail servers and TeX organisations.


--- Copyright 1994-1999 NTG.  All rights reserved ---
