% List of exceptions created by Karel Horak
% (Mathamatical Institute of Czechoslovak Acadamy of Science)
% Prague, April 1, 1991
%
\hyphenation{
dos\v t me-t\'o-da me-t\'o-dy ne-do-stat-ka-mi sep-tem-bra
}
