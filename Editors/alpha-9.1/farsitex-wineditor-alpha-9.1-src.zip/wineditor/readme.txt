This is a preview version of FarsiTeX Editor for Windows 9x/NT/2000. We do appreciate your feedback, so please do not hesitate to report any bugs you find or make any suggestions for improving FarsiTeX Editor.

Visit our homepage at http://www.farsitex.org
FarsiTeX Project Team