//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Ftexed.rc
//
#define IDD_ABOUTBOX                    100
#define ID_EDITBOX                      101
#define IDB_SPLASH                      102
#define IDR_MAINFRAME                   128
#define IDR_NONAMETYPE                  129
#define IDB_BITMAP1                     131
#define IDB_EN_CARET                    131
#define IDD_GOTO                        134
#define IDD_SEARCH                      135
#define IDD_DIALOGPRINT                 136
#define IDB_FA_CARET                    139
#define IDD_REPLACE                     141
#define IDC_GOTO_Line                   1003
#define IDC_RADIOHPLJ                   1004
#define IDC_RADIOHPLJH                  1005
#define IDC_RADIOLQL                    1006
#define IDC_RADIOLQM                    1007
#define IDC_RADIOLQH                    1008
#define IDC_EDITFROMPAGE                1009
#define IDC_EDITTOPAGE                  1010
#define IDC_EDITTOFILE                  1011
#define IDC_FIND_NEXT                   1013
#define IDC_REPLACE                     1014
#define IDC_REPLACE_ALL                 1015
#define ID_EDIT_GO                      32771
#define ID_FARSI                        32772
#define ID_ENGLISH                      32773
#define ID_SEARCH                       32774
#define ID_SearchAgain                  32775
#define ID_EDIT_SEARCH                  32776
#define ID_EDIT_SEARCHAGAIN             32777
#define ID_RUN_RUN                      32778
#define ID_RUN_ONLYRUN                  32779
#define ID_RUN_VIEW                     32781
#define ID_RUN_CNVRT                    32782
#define ID_RUN_LOG                      32783
#define ID_RUN_PS                       32784
#define ID_RUN                          32785
#define ID_GS                           32786
#define ID_RUN_GS                       32787
#define ID_SYNTAXOFF                    32788
#define ID_VIEW_DEF_MODE                32791
#define ID_DVI                          32793
#define ID_BUTTON32795                  32795
#define ID_DVIPS                        32796
#define ID_VIEW_OPTIONS_CARETCASE       32797
#define IDD_READ_HELP                   32798
#define ID_VIEW_OPTIONS_DEF_CARET_NEXT  32799
#define ID_VIEW_REFRESH                 32800
#define ID_EDIT_IMPORT                  32801
#define IDD_VISIT_HOMEPAGE              32802
#define ID_RUN_MKIND                    32803
#define ID_RUN_FTXTOUNI                 32804
#define ID_TEXT5                        59147
#define ID_LnCol                        59148

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        142
#define _APS_NEXT_COMMAND_VALUE         32805
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
