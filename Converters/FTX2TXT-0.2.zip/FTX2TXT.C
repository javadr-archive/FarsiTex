/* ****************************** */
/*      In the name of Allah      */
/*                                */
/*       FTX2TXT Convertor        */
/*     FarsiLaTeX.blogfa.com      */
/* ****************************** */
#include <stdio.h>
#include <stdlib.h>

void main(int argc, char *argv[])
{
    char cha, ans;

    FILE *in, *out, *log;
    in = fopen (argv[1], "r");
    out = fopen (argv[2], "w");
    printf("This is FTX2TXT, Version 0.2 (FarsiLaTeX.Blogfa)\n");
    if (argc != 3)
    {
	printf("! Undefined input/output file(s).\n\n<*>\n?");
	ans = getchar();
	if ((ans == 'h') || (ans == 'H'))
	    printf("Sorry, but I'm not programmed to handle this case.\nUsage: FTX2TEX <inputfile> <outputfile>\n[0]\nNo page of output.\n");
	exit(0);
    }
    ans = getc(in);
    ans = 0;
    cha = getc(in);
    while (cha != EOF)
    {
	if ((cha >= ' ') && (cha <= '~'))
	{
	    putc(cha, out);
	}
	else if (cha == '\n')
	{
	    char ch;
	    ch = getc(in);
	    ch = 0;
	    putc(cha, out);
	}
	else
	switch (cha)
	{
	case '\x8d':
	    putc('�', out);
	    putc('�', out);
	    break;
        case '\x8e':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\x8f':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\x90':
            putc('�', out);
	    putc('�', out);
	    break;
	case '\x91':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\x93':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\x92':
	    putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\x94':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\x95':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\x96':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\x97':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\x98':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\x99':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\x9a':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\x9b':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\x9c':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\x9d':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\x9e':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\x9f':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xa0':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xa1':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xa2':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xa3':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xa4':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xa5':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xa6':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xa7':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xa8':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xa9':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xaa':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xab':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xac':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xad':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xae':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xaf':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xc1':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xe0':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xc2':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xe1':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xe2':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xe3':
            putc('�', out);
	    putc('�', out);
	    break;
	case '\xe4':
            putc('�', out);
	    putc('�', out);
	    break;
	case '\xe5':
	    putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xe6':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xe7':
            putc('�', out);
	    putc('�', out);
	    break;
	case '\xe8':
            putc('�', out);
	    putc('�', out);
	    break;
	case '\xe9':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xea':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xeb':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xec':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xed':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xee':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xef':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xf0':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xf1':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xf2':
	    putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xf3':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xf4':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xf5':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xf6':
	    putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xf7':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xf8':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xf9':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xfa':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xfb':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xfc':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xfd':
	    putc('�', out);
	    putc('�', out);
            putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xfe':
            putc('�', out);
	    putc('�', out);
	    break;
	case '\xda':
	    putc(' ', out);
	    break;
	case '\xb4':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xb0':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xb1':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xb2':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xb3':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xbb':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xba':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xc4':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\x8a':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xcb':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\x8c':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xd5':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xbf':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xc0':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xc3':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\xb5': putc('#', out); break;
	case '\xb6': putc('$', out); break;
	case '\xb7': putc('%', out); break;
	case '\xb8': putc('&', out); break;
	case '\xbd': putc(')', out); break;
	case '\xbe': putc('(', out); break;
	case '\xc7': putc('/', out); break;
	case '\xc8': putc('*', out); break;
	case '\xc9': putc('~', out); break;
	case '\xca': putc(':', out); break;
	case '\xcc': putc('>', out); break;
	case '\xcd': putc('+', out); break;
	case '\xce': putc('=', out); break;
	case '\xcf': putc('<', out); break;
	case '\xd0': putc('@', out); break;
	case '\xd1': putc(']', out); break;
	case '\xd2': putc(92, out);  break;
	case '\xd3': putc('[', out); break;
	case '\xd4': putc('^', out); break;
	case '\xd7': putc('}', out); break;
	case '\xd8': putc('|', out); break;
	case '\xdd': putc('!', out); break;
	case '\xde': putc('{', out); break;
	case '\x80':
	    putc('�', out);
	    putc('�', out);
	    break;
	case '\x81':
            putc('�', out);
	    putc('�', out);
	    break;
	case '\x82':
            putc('�', out);
	    putc('�', out);
	    break;
	case '\x83':
            putc('�', out);
	    putc('�', out);
	    break;
	case '\x84':
            putc('�', out);
	    putc('�', out);
	    break;
	case '\x85':
            putc('�', out);
	    putc('�', out);
	    break;
	case '\x86':
            putc('�', out);
	    putc('�', out);
	    break;
	case '\x87':
            putc('�', out);
	    putc('�', out);
	    break;
	case '\x88':
            putc('�', out);
	    putc('�', out);
	    break;
	case '\x89':
            putc('�', out);
	    putc('�', out);
	    break;
	case '\xc6': putc('.', out); break;
	case '\x8b':
	    putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    putc('�', out);
	    break;
	}
	cha = getc(in);
    }

    fclose (in);
    fclose (out);
    log = fopen ("OUT.log", "w");
    fputs("In the name of Allah\n********************************\nHere is some information about your file: \n", log);
    fputs("\t[version 0.2 has no information about your file!] \n", log);
    fputs("Links:\n", log);
    fputs("\thttp://FarsiTeX.blogfa.com\n", log);
    fputs("\thttp://FarsiLaTeX.blogfa.com\n", log);
	fputs("\thttp://groups.google.com/group/farsilatex?hl=fa\n\n", log);
    fputs("simorgh43@gmail.com", log);
    fclose (log);
    printf("[1]\nOutput written on %s\nTranscript written on OUT.log.\n", argv[2]);
}