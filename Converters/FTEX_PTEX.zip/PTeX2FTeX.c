/* 
*	In the name of Allah
*	
*	TeX-Parsi > FarsiTeX Convertor
*	FarsiLaTeX.blogfa.com
*	Simorgh43@gmail.com
*	GPL
*/
#include <stdio.h>
#include <stdlib.h>
#define MAX 350
/* Maximum latin line length */

void main (int argc, char *argv[])
{
	FILE *in, *out;
	int c;
	short i, j;
	char latin[MAX];
	char d;
	
	in = fopen (argv[1], "r");
	out = fopen (argv[2], "w");
	
	fputs ("<�ړ��������������\n<", out);
	while ((c = getc (in)) != EOF)
		if (c >= 32 && c <= 127) {
            i = 0;
            latin [i] = c;
            while ((d = getc (in)) >= ' ' && d <= '~')
                latin [++i] = d;
            for (j = i; j >= 0; --j)
                fprintf (out, "%c", latin [j]);
			/* Here we reverse the latin line (or latin string). */
            ungetc (d, in);
		}
		else
			switch (c) {
            case '\n':
                putc (c, out);
                d = getc (in);
                if (d >= ' ' && d <= '~')
                    putc ('>', out);
					/*	English mode in FTeX Editor */
                else
                    putc ('<', out);
					/*	Persian mode in FTeX Editor */
                ungetc (d, in);
                break;
			case 129: putc ('\xd0', out); break;
			case 130: putc ('\xc8', out); break;
			case 131: putc ('\xb6', out); break;
			case 160: putc ('\xda', out); break;
			/*	
			*	case 128:
			*	case 132:
			*	case 136:
			*	case 137:
			*	case 138:
			*	case 133:	
			*	
			*	These characters dont't have any 
			*	equivalent	in FarsiTeX Editor.
			*/
			case 134: putc ('\x7e', out); break;				
			case 135: putc ('\xb8', out); break;				
			case 139: putc ('\xd7', out); break;				
			
			case 140: putc ('\xde', out); break;				
			case 141: putc ('\xd9', out); break;				
			case 142: putc ('\xc0', out); break;				
			case 143: putc ('\xc3', out); break;				
			case 144: putc ('\xbd', out); break;				
			case 145: putc ('\xbe', out); break;				
			case 146: putc ('\xd1', out); break;				
			case 147: putc ('\xd3', out); break;				
			case 148: putc ('\x8b', out); break;				
			case 149: putc ('\xb5', out); break;				
				
			case 150: putc ('\xb7', out); break;				
			case 151: putc ('\x2c', out); break;				
			case 152: putc ('\xcc', out); break;				
			case 153: putc ('\xce', out); break;				
			case 154: putc ('\xcf', out); break;				
			case 155: putc ('\x5c', out); break;				
			case 156: putc ('\xcd', out); break;
			/*	'*' => '+' */
			case 157: putc ('\xd2', out); break;				
			case 158: putc ('\xcd', out); break;				
			case 159: putc ('\xc5', out); break;				
			
			case 161: putc ('\xbc', out); break;				
			case 162: putc ('\xc6', out); break;				
			case 163: putc ('\x8c', out); break;				
			case 164: putc ('\xdd', out); break;				
			case 165: putc ('\xca', out); break;				
			case 166: putc ('\xcb', out); break;				
			case 167: putc ('\x8a', out); break;				
			case 168: putc ('\x60', out); break;				
			case 169: putc ('\xb2', out); break;				
				
			case 170: putc ('\xb1', out); break;				
			case 171: putc ('\xb0', out); break;				
			case 172: putc ('\xb3', out); break;				
			case 173: putc ('\xbb', out); break;				
			case 174: putc ('\xd4', out); break;				
			case 175: putc ('\xd8', out); break;				
			case 176: putc ('\x80', out); break;				
			case 177: putc ('\x81', out); break;				
			case 178: putc ('\x82', out); break;				
			case 179: putc ('\x83', out); break;				
				
			case 180: putc ('\x84', out); break;				
			case 181: putc ('\x85', out); break;				
			case 182: putc ('\x86', out); break;				
			case 183: putc ('\x87', out); break;				
			case 184: putc ('\x88', out); break;				
			case 185: putc ('\x89', out); break;				
			case 186: putc ('\xb4', out); break;				
			case 187: putc ('\x8d', out); break;				
			case 188: putc ('\x8f', out); break;				
			case 189: putc ('\x90', out); break;				
			
			case 190: putc ('\x91', out); break;				
			case 191: putc ('\x92', out); break;				
			case 192: putc ('\x93', out); break;				
			case 193: putc ('\x94', out); break;				
			case 194: putc ('\x95', out); break;				
			case 195: putc ('\x96', out); break;				
			case 196: putc ('\x97', out); break;				
			case 197: putc ('\x98', out); break;				
			case 198: putc ('\x99', out); break;				
			case 199: putc ('\x9a', out); break;				
				
			case 200: putc ('\x9b', out); break;				
			case 201: putc ('\x9c', out); break;				
			case 202: putc ('\x9d', out); break;				
			case 203: putc ('\x9e', out); break;				
			case 204: putc ('\x9f', out); break;				
			case 205: putc ('\xa0', out); break;				
			case 206: putc ('\xa1', out); break;				
			case 207: putc ('\xa2', out); break;				
			case 208: putc ('\xa3', out); break;				
			case 209: putc ('\xa4', out); break;				
				
			case 210: putc ('\xa5', out); break;				
			case 211: putc ('\xa6', out); break;				
			case 212: putc ('\xa7', out); break;				
			case 213: putc ('\xa8', out); break;				
			case 214: putc ('\xa9', out); break;				
			case 215: putc ('\xaa', out); break;				
			case 216: putc ('\xab', out); break;				
			case 217: putc ('\xac', out); break;				
			case 218: putc ('\xad', out); break;				
			case 219: putc ('\xae', out); break;				
						
			case 220: putc ('\xc1', out); break;				
			case 221: putc ('\xaf', out); break;				
			case 222: putc ('\xc2', out); break;				
			case 223: putc ('\xe0', out); break;				
			case 224: putc ('\xe1', out); break;				
			case 225: putc ('\xe4', out); break;				
			case 226: putc ('\xe2', out); break;				
			case 227: putc ('\xe3', out); break;				
			case 228: putc ('\xe5', out); break;				
			case 229: putc ('\xe8', out); break;				
				
			case 230: putc ('\xe6', out); break;				
			case 231: putc ('\xe7', out); break;				
			case 232: putc ('\xe9', out); break;				
			case 233: putc ('\xea', out); break;				
			case 234: putc ('\xeb', out); break;				
			case 235: putc ('\xec', out); break;				
			case 236: putc ('\xed', out); break;				
			case 237: putc ('\xee', out); break;				
			case 238: putc ('\xef', out); break;				
			case 239: putc ('\xf0', out); break;				
				
			case 240: putc ('\xf1', out); break;				
			case 241: putc ('\xf2', out); break;				
			case 242: putc ('\xf3', out); break;				
			case 243: putc ('\xf4', out); break;				
			case 244: putc ('\xf5', out); break;				
			case 245: putc ('\xf6', out); break;				
			case 246: putc ('\xf7', out); break;				
			case 247: putc ('\xf8', out); break;				
			case 248: putc ('\xf9', out); break;				
			case 249: putc ('\xfb', out); break;				
				
			case 250: putc ('\xf2', out); break;				
			case 251: putc ('\xfa', out); break;				
			case 252: putc ('\xfd', out); break;				
			case 253: putc ('\xfe', out); break;				
			case 254: putc ('\xfc', out); break;				
			case 255: putc ('\x8e', out); break;				
			}
}