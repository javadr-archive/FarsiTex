/* 
*	In the name of Allah
*	
*	TeX-Parsi > FarsiTeX Convertor
*	FarsiLaTeX.blogfa.com
*	Simorgh43@gmail.com
*	GPL
*/
#include <stdio.h>
#include <stdlib.h>
#define MAX 350
/* Maximum latin line length */

void main(int argc, char *argv[])
{
	FILE *in, *out;
    int c;
    short i, j;
	char latin[MAX];
	char d;    

    in = fopen (argv[1], "r");
    out = fopen (argv[2], "w");

    c = getc(in);
	fputs ("��������������������\n", out);
    while ((c = getc (in)) != EOF)
		if (c >= '\x20' && c <= '\x7e') {
			i = 0;
			latin [i] = c;
			while ((d = getc (in)) >= '\x20' && d <= '\x7e')
				latin [++i] = d;
			ungetc (d, in);
			for (j = i; j >= 0; --j)
				fprintf (out, "%c", latin [j]);
				/* Here we reverse the latin line (or latin string). */		
		}
		else
			switch (c) {
			case '\n':
				putc (c, out);
				getc (in);
				/* 	
				*	Due to removeing a '<' or '>', that appeares 
				*	at any new line.
				*/
				break;
			case 128: putc (176, out); break;
			case 129: putc (177, out); break;
			case 130: putc (178, out); break;
			case 131: putc (179, out); break;
			case 132: putc (180, out); break;
			case 133: putc (181, out); break;
			case 134: putc (182, out); break;
			case 135: putc (183, out); break;
			case 136: putc (184, out); break;
			case 137: putc (185, out); break;
			case 138: putc (167, out); break;
			case 139: putc (148, out); break;
			case 140: putc (163, out); break;
			case 141: putc (187, out); break;
			case 142: putc (255, out); break;
			case 143: putc (173, out); break;

			case 144: putc (189, out); break;
			case 145: putc (190, out); break;
			case 146: putc (191, out); break;
			case 147: putc (192, out); break;
			case 148: putc (193, out); break;
			case 149: putc (194, out); break;
			case 150: putc (195, out); break;
			case 151: putc (196, out); break;
			case 152: putc (197, out); break;
			case 153: putc (198, out); break;
			case 154: putc (199, out); break;
			case 155: putc (200, out); break;
			case 156: putc (201, out); break;
			case 157: putc (202, out); break;
			case 158: putc (203, out); break;
			case 159: putc (204, out); break;

			case 160: putc (205, out); break;
			case 161: putc (206, out); break;
			case 162: putc (207, out); break;
			case 163: putc (208, out); break;
			case 164: putc (209, out); break;
			case 165: putc (210, out); break;
			case 166: putc (211, out); break;
			case 167: putc (212, out); break;
			case 168: putc (213, out); break;
			case 169: putc (214, out); break;
			case 170: putc (215, out); break;
			case 171: putc (216, out); break;
			case 172: putc (217, out); break;
			case 173: putc (218, out); break;
			case 174: putc (219, out); break;
			case 175: putc (221, out); break;

			case 176: putc (171, out); break;
			case 177: putc (170, out); break;
			case 178: putc (169, out); break;
			case 179: putc (172, out); break;
			case 180: putc (186, out); break;
			case 181: putc (149, out); break;
			case 182: putc (131, out); break;
			case 183: putc (150, out); break;
			case 184: putc (135, out); break;
			case 185: putc (39,  out); break;
			case 186: 
				fprintf (out, "%c%c%c%c", 157, 187, 140, 139);
				break;
			/*	
			*	case 217
			*	case 219
			*	case 220
			*	case 223
			*	
			*	These characters dont't have any 
			*	equivalent	in FedWrd Editor.
			*/
			case 187: putc (173, out); break;
			case 188: putc (161, out); break;
			case 189: putc (144, out); break;
			case 190: putc (145, out); break;
			case 191: 
				fprintf (out, "%c%c%c%c", 157, 248, 157, 160);
				break;
			case 192: putc (142, out); break;
			case 193: putc (220, out); break;
			case 194: putc (222, out); break;
			case 195: putc (143, out); break;
			case 196: 
				fprintf (out, "%c%c", 157, 174);
				break;
			case 197: putc (159, out); break;
			case 198: putc (162, out); break;
			case 199: putc ('/', out); break;
			case 200: putc (130, out); break;
			case 201: putc (134, out); break;
			case 202: putc (165, out); break;
			case 203: putc (166, out); break;
			case 204: putc (152, out); break;
			case 205: putc (158, out); break;
			case 206: putc (153, out); break;
			case 207: putc (154, out); break;

			case 208: putc (129, out); break;
			case 209: putc (146, out); break;
			case 210: putc (157, out); break;
			case 211: putc (147, out); break;
			case 212: putc (174, out); break;
			case 213: putc ('_', out); break;
			case 214: putc (96,  out); break;
			case 215: putc (139, out); break;
			case 216: putc (175, out); break;
			case 218: putc (160, out); break;
			case 221: putc (164, out); break;
			case 222: putc (140, out); break;

			case 224: putc (223, out); break;
			case 225: putc (224, out); break;
			case 226: putc (226, out); break;
			case 227: putc (227, out); break;
			case 228: putc (225, out); break;
			case 229: putc (228, out); break;
			case 230: putc (230, out); break;
			case 231: putc (231, out); break;
			case 232: putc (229, out); break;
			case 233: putc (232, out); break;
			case 234: putc (233, out); break;
			case 235: putc (234, out); break;
			case 236: putc (235, out); break;
			case 237: putc (236, out); break;
			case 238: putc (237, out); break;
			case 239: putc (238, out); break;

			case 240: putc (239, out); break;
			case 241: putc (240, out); break;
			case 242: putc (241, out); break;
			case 243: putc (242, out); break;
			case 244: putc (243, out); break;
			case 245: putc (244, out); break;
			case 246: putc (245, out); break;
			case 247: putc (246, out); break;
			case 248: putc (247, out); break;
			case 249: putc (248, out); break;
			case 250: putc (251, out); break;
			case 251: putc (249, out); break;
			case 252: putc (254, out); break;
			case 253: putc (252, out); break;
			case 254: putc (253, out); break;
			}

    fclose (in);
    fclose (out);
}