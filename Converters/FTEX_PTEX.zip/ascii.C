/* 
*	In the name of Allah 
*	
*	Program to show characters with 
*	their  codes (Order: Decimal, Hex).
*	Press <Enter>.
*/
#include <stdio.h>
main()
{
    unsigned char ch, i;

    for (i = 0; i < 255; ++i) 
		printf ("%c\t%d\t%x\n", ch = getchar() + i, ch, ch);
}