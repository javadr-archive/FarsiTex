/* ****************************** */
/*      In the name of Allah      */
/*                                */
/*  Unicode > FarsiTeX Convertor  */
/*     General Public License     */
/*      simorgh43@gmail.com       */
/* ****************************** */
#include <stdio.h>
#define ISSPACE ((f = getc (in)) == '\n' || f == '\t' || f == ' ' \
                                         || f == '.'  || f == ':' || f == '?' \
                                         || f == ')'  || f == '(' || f == '~' \
                                         || f == '\\' || f == '[' || f == ']' \
                                         || f == '{'  || f == '}' || f == '!' \
                                         || f == '�'  || f == '�' || f == '�' \
                                         || f == ','  || f == ';' || f == '/' \
                                         || f == '`')

#define ISBLANK (f == ' ' || f == '\n' || f == '.' || \
                 f == ':' || f == '\t' || f == '?' || \
                 f == '!' || f == '\\' || f == '[' || \
                 f == ']' || f == ')'  || f == '(' || \
                 f == '{' || f == '}'  || f == '�' || \
                 f == '�' || f == '�'  || f == ',' || \
                 f == ';' || f == '/'  || f == '`')

#define NONEJOINABLE 0
#define JOINABLE 1

void main (int argc, char *argv[])
{
    int c;
    short state, i, j;
    FILE *in, *out;
    char d, e, f, g, digit[25];

    in = fopen (argv[1], "r");
    out = fopen (argv[2], "w");

    fputs ("<�ړ��������������\n<", out);
    while ((d = getc (in)) != EOF)
                    switch (d)
                    {
                    case '\n':
                        putc (d, out);
                        e = getc (in);
                        if (e == '>')
                        {
                            putc ('>', out);
                            while ((f = getc (in)) != '\n')
                                putc (f, out);
                            ungetc (f, in);
                        }
                        else
                        {
                            ungetc (e, in);
                            putc ('<', out);
                        }
                        state = NONEJOINABLE;
                        break;
                    case '\t':
                        fputs ("    ", out);
                        state = NONEJOINABLE;
                        break;
                    case '0' ... '9':
                        i = 0;
                        digit [i] = d;
                        while ((e = getc (in)) >= '0' && e <= '9')
                            digit [++i] = e;
                        for (j = i; j >= 0; --j)
                            fprintf (out, "%c", 'P' + digit[j]);
                        ungetc (e, in);
                        break;
                    case 'A' ... 'Z':
                        putc (d, out);
                        state = NONEJOINABLE;
                        break;
                    case 'a' ... 'z':
                        putc (d, out);
                        state = NONEJOINABLE;
                        break;
                    case '!': putc ('\xdd', out); state = NONEJOINABLE; break;
                    case '"': putc ('\x22', out); state = NONEJOINABLE; break;
                    case '#': putc ('\xb5', out); state = NONEJOINABLE; break;
                    case '$':
                        putc (d, out);
                        if ((e = getc (in)) == '$')
                        {
                            putc (e, out);
                            while ((f = getc (in)) != '$')
                                putc (f, out);
                            putc (f, out);
                            putc (getc (in), out);
                        }
                        else if (e != '$')
                        {
                            putc (e, out);
                            while ((f  = getc (in)) != '$')
                                putc (f, out);
                            putc (f, out);
                        }
                        break;
                    case '%': putc ('\xb7', out); state = NONEJOINABLE; break;
                    case '&': putc ('\xb8', out); state = NONEJOINABLE; break;
                    case '\x27':putc('\xb9',out); state = NONEJOINABLE; break;
                    case '(': putc ('\xbe', out); state = NONEJOINABLE; break;
                    case ')': putc ('\xbd', out); state = NONEJOINABLE; break;
                    case '*': putc ('\xc8', out); state = NONEJOINABLE; break;
                    case '@':
                        e = getc (in);
                        switch (e)
                        {
                        case ' ' ... '~':
                            putc (e, out);
                            while ((f = getc (in)) != '@')
                                putc (f, out);
                            break;
                        default:
                            putc ('\xd0', out);
                            ungetc (e, in);
                            break;
                        }
                        break;
                    case ',': putc ('\x8a', out); state = NONEJOINABLE; break;
                    case '-': putc ('\xc5', out); state = NONEJOINABLE; break;
                    case '.': putc ('\xc6', out); state = NONEJOINABLE; break;
                    case '/': putc ('\xc7', out); state = NONEJOINABLE; break;
                    case ':': putc ('\xca', out); state = NONEJOINABLE; break;
                    case ';': putc ('\xcb', out); state = NONEJOINABLE; break;
                    case '<': putc ('\xcc', out); state = NONEJOINABLE; break;
                    case '=': putc ('\xce', out); state = NONEJOINABLE; break;
                    case '>': putc ('\xcf', out); state = NONEJOINABLE; break;
                    case '?': putc ('\x8c', out); state = NONEJOINABLE; break;
                    case '+': putc ('\xcd', out); state = NONEJOINABLE; break;
                    case '[': putc ('\xd3', out); state = NONEJOINABLE; break;
                    case '\\':putc ('\xd2', out); state = NONEJOINABLE; break;
                    case ']': putc ('\xd1', out); state = NONEJOINABLE; break;
                    case '^': putc ('\xd4', out); state = NONEJOINABLE; break;
                    case '_': putc ('\xd5', out); state = NONEJOINABLE; break;
                    case '`': putc ('\xd6', out); state = NONEJOINABLE; break;
                    case '{': putc ('\xde', out); state = NONEJOINABLE; break;
                    case '|': putc ('\xd8', out); state = NONEJOINABLE; break;
                    case '}': putc ('\xd7', out); state = NONEJOINABLE; break;
                    case '~': putc ('\xc9', out); state = NONEJOINABLE; break;
                    case ' ': putc ('\xda', out); state = NONEJOINABLE; break;
                    case '�':
                        e = getc (in);
                        switch (e)
                        {
                        case '�': putc ('\x8e', out); state = JOINABLE; break;
                        case '�': putc ('\x8f', out); state = NONEJOINABLE; break;
                        case '�': putc ('\x8d', out); state = NONEJOINABLE; break;
                        case '�':
                            if ((ISSPACE) && (state == JOINABLE))
                                putc ('\x91', out);
                            else if (ISBLANK && (state != JOINABLE))
                                putc ('\x90', out);
                            else if (!ISBLANK && (state == JOINABLE))
                                putc ('\x91', out);
                            else if (!ISBLANK && state == NONEJOINABLE)
                                putc ('\x90', out);
                            ungetc (f, in);
                            state = NONEJOINABLE;
                            break;
                        case '�':
                            if (ISSPACE)
                            {
                                putc ('\x92', out);
                                state = NONEJOINABLE;
                            }
                            else
                            {
                                putc ('\x93', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);
                            break;
                        case '�':
                            if (ISSPACE)
                            {
                                putc ('\x96', out);
                                state = NONEJOINABLE;
                            }
                            else
                            {
                                putc ('\x97', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);
                            break;
                        case '�':
                            if (ISSPACE)
                            {
                                putc ('\x98', out);
                                state = NONEJOINABLE;
                            }
                            else
                            {
                                putc ('\x99', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);
                            break;
                        case '�':
                            if (ISSPACE)
                            {
                                putc ('\x9a', out);
                                state = NONEJOINABLE;
                            }
                            else
                            {
                                putc ('\x9b', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);
                            break;
                        case '�':
                            if (ISSPACE)
                            {
                                putc ('\x9e', out);
                                state = NONEJOINABLE;
                            }
                            else
                            {
                                putc ('\x9f', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);
                            break;
                        case '�':
                            if (ISSPACE)
                            {
                                putc ('\xa0', out);
                                state = NONEJOINABLE;
                            }
                            else
                            {
                                putc ('\xa1', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);
                            break;
                        case '�':
                            putc ('\xa2', out);
                            state = NONEJOINABLE;
                            break;
                        case '�':
                            putc ('\xa3', out);
                            state = NONEJOINABLE;
                            break;
                        case '�':
                            putc ('\xa4', out);
                            state = NONEJOINABLE;
                            break;
                        case '�':
                            putc ('\xa5', out);
                            state = NONEJOINABLE;
                            break;
                        case '�':
                            if (ISSPACE)
                            {
                                putc ('\xA7', out);
                                state = NONEJOINABLE;
                            }
                            else
                            {
                                putc ('\xA8', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);
                            break;
                        case '�':
                            if (ISSPACE)
                            {
                                putc ('\xa9', out);
                                state = NONEJOINABLE;
                            }
                            else
                            {
                                putc ('\xaa', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);
                            break;
                        case '�':
                            if (ISSPACE)
                            {
                                putc ('\xab', out);
                                state = NONEJOINABLE;
                            }
                            else
                            {
                                putc ('\xac', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);
                            break;
                        case '�':
                            if (ISSPACE)
                            {
                                putc ('\xad', out);
                                state = NONEJOINABLE;
                            }
                            else
                            {
                                putc ('\xae', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);
                            break;
                        case '�':
                            if (ISSPACE)
                            {
                                putc ('\xc1', out);
                                state = NONEJOINABLE;
                            }
                            else
                            {
                                putc ('\xaf', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);
                            break;
                        case '�':
                            if (ISSPACE)
                            {
                                putc ('\xc2', out);
                                state = NONEJOINABLE;
                            }
                            else
                            {
                                putc ('\xe0', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);
                            break;
                        case '�':
                            if ((ISSPACE) && (state == JOINABLE))
                            {
                                putc ('\xe2', out);
                                state = NONEJOINABLE;
                            }
                            else if (ISBLANK && (state != JOINABLE))
                            {
                                putc ('\xe1', out);
                                state = NONEJOINABLE;
                            }
                            else if (!ISBLANK && (state == JOINABLE))
                            {
                                putc ('\xe3', out);
                                state = JOINABLE;
                            }
                            else if (!ISBLANK && state == NONEJOINABLE)
                            {
                                putc ('\xe4', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);
                            break;
                        case '�':
                            if ((ISSPACE) && state == JOINABLE)
                            {
                                putc ('\xe6', out);
                                state = NONEJOINABLE;
                            }
                            else if (ISBLANK && (state != JOINABLE))
                            {
                                putc ('\xe5', out);
                                state = NONEJOINABLE;
                            }
                            else if (!ISBLANK && (state == JOINABLE))
                            {
                                putc ('\xe7', out);
                                state = JOINABLE;
                            }
                            else if (!ISBLANK && state == NONEJOINABLE)
                            {
                                putc ('\xe8', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);
                            break;
                        case '�': putc ('\x8a', out); state = NONEJOINABLE; break;
                        case '�': putc ('\xbf', out); state = NONEJOINABLE; break;
                        case '�': putc ('\xcb', out); state = NONEJOINABLE; break;
                        }
                        break;
                    case'�':
                        e = getc (in);
                        switch (e)
                        {
                        case '�':
                            if (ISSPACE)
                            {
                                putc ('\x94', out);
                                state = NONEJOINABLE;
                            }
                            else
                            {
                                putc ('\x95', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);
                            break;
                        case '�':
                            if (ISSPACE)
                            {
                                putc ('\xe9', out);
                                state = NONEJOINABLE;
                            }
                            else
                            {
                                putc ('\xea', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);
                            break;
                        case '�':
                            if (ISSPACE)
                            {
                                putc ('\xeb', out);
                                state = NONEJOINABLE;
                            }
                            else
                            {
                                putc ('\xec', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);
                            break;
                        case '�':
                            if (ISSPACE)
                            {
                                putc ('\xf1', out);
                                ungetc (f, in);
                                state = NONEJOINABLE;
                                break;
                            }
                            if (f == '�')
                            {
                                g = getc (in);
                                if (g == '�')
                                {
                                    putc ('\xf2', out);
                                    state = NONEJOINABLE;
                                    break;
                                }
                                else
                                {
                                    putc ('\xf3', out);
                                    ungetc (g, in);
                                    ungetc (f, in);
                                    state = JOINABLE;
                                    break;
                                }
                            }
                            else 
                            {
                                putc ('\xf3', out);
                                ungetc (f, in);
                                state = JOINABLE;
                                break;
                            }
                            break;
                        case '�':
                            if (ISSPACE)
                            {
                                putc ('\xf4', out);
                                state = NONEJOINABLE;
                            }
                            else
                            {
                                putc ('\xf5', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);
                            break;
                        case '�':
                            if (ISSPACE)
                            {
                                putc ('\xf6', out);
                                state = NONEJOINABLE;
                            }
                            else
                            {
                                putc ('\xf7', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);

                            break;
                        case '�': putc ('\xf8', out); state = NONEJOINABLE; break;
                        case '�':
                            if ((ISSPACE) && (state == JOINABLE))
                            {
                                putc ('\xf9', out);
                                state = NONEJOINABLE;
                            }
                            else if (ISBLANK && (state != JOINABLE))
                            {
                                putc ('\xf9', out);
                                state = NONEJOINABLE;
                            }
                            else if (!ISBLANK && (state == JOINABLE))
                            {
                                putc ('\xfa', out);
                                state = JOINABLE;
                            }
                            else if (!ISBLANK && state == NONEJOINABLE)
                            {
                                putc ('\xfb', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);

                            break;
                        case '�':
                            if ((ISSPACE) && state == NONEJOINABLE)
                            {
                                putc ('\xfd', out);
                                state = NONEJOINABLE;
                            }
                            else if (ISBLANK && (state != NONEJOINABLE))
                            {
                                putc ('\xfc', out);
                                state = NONEJOINABLE;
                            }
                            else 
                            {
                                putc ('\xfe', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);
                            break;
                        case '�': putc ('\xb0', out); state = NONEJOINABLE; break;
                        case '�': putc ('\xb1', out); state = NONEJOINABLE; break;
                        case '�': putc ('\xb2', out); state = NONEJOINABLE; break;
                        case '�': putc ('\xb3', out); state = NONEJOINABLE; break;
                        case '�': putc ('\xb4', out); state = NONEJOINABLE; break;
                        case '�': putc ('\xb9', out); state = NONEJOINABLE; break;
                        case '�': putc ('\xba', out); state = NONEJOINABLE; break;
                        case '�': putc ('\xbb', out); state = NONEJOINABLE; break;
                        case '�': putc ('\xbc', out); state = NONEJOINABLE; break;
                        case '�': putc ('\xc4', out); state = NONEJOINABLE; break;
                        case '�': putc ('\x8b', out); state = JOINABLE; break;

                        }
                        break;
                    case '�':
                        e = getc (in);
                        switch (e)
                        {
                        case '�':
                            if (ISSPACE)
                            {
                                putc ('\x9c', out);
                                state = NONEJOINABLE;
                            }
                            else
                            {
                                putc ('\x9d', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);
                            break;
                        case '�':
                            putc ('\xa6', out);
                            state = NONEJOINABLE;
                            break;
                        case '�':
                            if (ISSPACE)
                            {
                                putc ('\xed', out);
                                state = NONEJOINABLE;
                            }
                            else
                            {
                                putc ('\xee', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);
                            break;
                        case '�':
                            if (ISSPACE)
                            {
                                putc ('\xef', out);
                                state = NONEJOINABLE;
                            }
                            else
                            {
                                putc ('\xf0', out);
                                state = JOINABLE;
                            }
                            ungetc (f, in);
                            break;
                        }
                        break;
                    case '�':
                        e = getc (in);
                        switch (e)
                        {
                        case '�':
                            if ((ISSPACE) && state == NONEJOINABLE)
                            {
                                putc ('\xfd', out);
                                state = NONEJOINABLE;
                            }
                            else if (ISBLANK && (state != NONEJOINABLE))
                            {
                                putc ('\xfc', out);
                                state = NONEJOINABLE;
                            }
                            else
                            {
                                putc ('\xfe', out);
                                state = JOINABLE;

                            }
                            ungetc (f, in);
                            break;
                        case '�': putc ('\x80', out); break;
                        case '�': putc ('\x81', out); break;
                        case '�': putc ('\x82', out); break;
                        case '�': putc ('\x83', out); break;
                        case '�': putc ('\x84', out); break;
                        case '�': putc ('\x85', out); break;
                        case '�': putc ('\x86', out); break;
                        case '�': putc ('\x87', out); break;
                        case '�': putc ('\x88', out); break;
                        case '�': putc ('\x89', out); break;
                        }
                        break;
                    case '�':
                        e = getc (in);
                        switch (e)
                        {
                        case '�': putc ('\xc0', out); state = NONEJOINABLE; break;
                        case '�': putc ('\xc3', out); state = NONEJOINABLE; break;
                        }
                        break;
                    }
    fclose (in);
    fclose (out);
}